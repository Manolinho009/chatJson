<?php

require_once('./Models/Conversa.php');

require_once('./SleekDB/src/Store.php');



use SleekDB\Store;


class ConversaController{
    
    
    public static function insertMsg(Conversa $conversa){
        
        $chatStore = new Store('chatData', __DIR__ . "/database");
// CAMPPOS DO BANCO DE DADOS 
    // protected $msg;
    // protected $hora;
    // protected $destinatario;
    // protected $origem;
    // protected $status;
    // protected $link;


    $msg = [
        'msg' => $conversa->get_msg(),
        'hora' => $conversa->get_hora(),
        'destinatario' => $conversa->get_destinatario(),
        'origem' => $conversa->get_origem(),
        'status' => $conversa->get_status(),
        'link' => $conversa->get_link()
    ];
    // Insert the data.
    $msgI = $chatStore->insert($msg);
    return $msgI;
    }



    public static function getMsg(Conversa $conversa){
        $chatStore = new Store('chatData', __DIR__ . "/database");

        try{
            $msgs = $chatStore->findBy([[["destinatario" , "=", $conversa->get_destinatario()],'AND',["origem" , "=", $conversa->get_origem()],'OR',["destinatario" , "=", $conversa->get_origem()],'AND',["origem" , "=", $conversa->get_destinatario()]]]);
            
            $resultado = [];
            foreach ($msgs as $key => $value) {
                # code...
                $convResult = new Conversa($value['msg'], $value['hora'], $value['destinatario'], $value['origem'], $value['status'], $value['link']);
                array_push($resultado,$convResult);
            }
            return $resultado;
        }catch(Exception $e){
            return 'ERRO BANCO -'.$e->getMessage();
        }

    }
    
    
    public static function getRecent($user){
        $chatStore = new Store('chatData', __DIR__ . "/database");

        try{
            // $msgs = $chatStore->findBy(['destinatario','=',$user]);

            // $resents = $chatStore->createQueryBuilder()
            // ->where(["destinatario", "=", $user])
            // ->groupBy(["destinatario"], 'origem')
            // ->getQuery()
            // ->fetch();
            
            $resents = $chatStore->createQueryBuilder()
            ->select([ 
              "destinatario", 
              "origem"
            ])
            ->where(["destinatario", "=", $user])
            ->groupBy(
              ["destinatario", "origem"]
            )
            ->getQuery()
            ->fetch();
            
            $resultado = [];
            foreach ($resents as $key => $value) {
                # code...
                // echo '<script>console.log("'.$value['msg'].'")</script>';
                // $convResult = new Conversa('', '', $value['destinatario'], $value['origem'], '', '');
                array_push($resultado,$value);
            }
            return $resultado;
        }catch(Exception $e){
            return 'ERRO BANCO -'.$e->getMessage();
        }

    }
}


?>