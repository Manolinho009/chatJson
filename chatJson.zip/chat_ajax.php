<?php

// include('Models/Conversa.php');
require('Controllers/ConversaController.php');
// require('SleekDB\src\Store.php');


use SleekDB\Store;


switch (array_keys($_POST)[0]) {
    case "1":
        $destinatario = $_POST['destinatario'];
        $usuario = $_POST['user'];

        $conv = new Conversa($_POST['mensagem'],getdate("h:i:sa"),$destinatario,$usuario,'0','');
        $conversa = ConversaController::insertMsg($conv);
        # code...
        break;
    
    case "2":
        # code...
        $destinatario = $_POST['destinatario'];
        $usuario = $_POST['user'];

        $conv = new Conversa('','',$destinatario,$usuario,'','');

        $conversa = ConversaController::getMsg($conv);

        $final = '';
        foreach ($conversa as $key => $value) {
            if($value->get_destinatario() == $usuario){
                $final = $final.'<br>'.$value->print_receb();
            }else{
                $final = $final.'<br>'.$value->print_env();
            }
            
        }

        echo $final;

        break;
}

?>