<?php
require_once "conection.php";
require_once "wo.php";
require_once "mensagem.php";
require_once "wo_controller.php";
require_once "msg_controller.php";

$conection = new Conection("conversa","localhost","root","");
$woController = new WoController();
$msgController = new MsgController();

?>

<html>
    <head>

    </head>
    <body>
        
    <?php
            if(isset($_POST['nome'])){
                $origem = addslashes($_POST['nome']);
                $msg = addslashes($_POST['msg']);
                $destino = 'joao';

                $msgN = new Msg();

                $msgN->set_msg($msg);
                $msgN->set_origem($origem);
                $msgN->set_destino($destino);

                $msgController->insert_msg($msgN,$conection->get_pdo());
            }
        
        ?>

        <form action="POST">
            <input type="text" name="nome">
            <input type="text" name="msg">
            <input type="submit">
        </form>

    </body>
</html>