<html>
<head>

</head>
<body>
    


<div id='chat'></div>

<form action="POST" action="index.php">
    <input type="text" name="nome" placeholder="NOME">
    <input type="text" name="msg" placeholder="msg">
    <input type="submit" value="enviar">
</form>

<?php

include("conection1.php");

$nome = $_POST['nome'];
$msg = $_POST['msg'];

$pdo->query("INSERT INTO chat1 (nome,msg) VALUE'$nome', '$msg'")

?>

<script>

function ajax(){
    var req = new XMLHttpRequest();
    req.onreadystatechange = function() {
        if(req.readyState == 4 && req.status == 200){
            document.getElementById('chat').innerHTML = req.responseText

        }
        req.open('GET', 'chat.php',true);
        req.send();

    }

    setInterval(function(){ajax();},1000);


}


</script>
</body>
</html>