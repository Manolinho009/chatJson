<?php


try{

    $pdo = new PDO('mysql:dbname=chat;host=localhost',"root","");

}catch(PDOException $e){
    echo "ERRO CONECTION - ".$e->getMessage();
}

?>