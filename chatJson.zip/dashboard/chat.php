<html>
<head>

</head>
<body>
    


<div id='chat'></div>

<form action="POST" action="chat.php">
    <input type="text" name="nome" placeholder="NOME">
    <input type="text" name="msg" placeholder="msg">
    <input type="submit" value="enviar">
</form>

<?php

require_once "conection1.php";

try{
$nome = 'nome';// $_POST['nome'];
$msg ='ola mundo';// $_POST['msg'];

$pdo->query("INSERT INTO chat1 (nome,msg) VALUE 'thithi', 'Aba'");
}
catch(Exception $e){
    echo $e->getMessage();
}

?>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js" integrity="sha384-oBqDVmMz9ATKxIep9tiCxS/Z9fNfEXiDAYTujMAeBAsjFuCZSmKbSSUnQlmh/jp3" crossorigin="anonymous"></script>

<!-- 
<script>

function ajax(){
    var req = new XMLHttpRequest();
    req.onreadystatechange = function() {
        if(req.readyState == 4 && req.status == 200){
            document.getElementById('chat').innerHTML = req.responseText

        }
        req.open('GET', 'chat.php',true);
        req.send();

    }

    setInterval(function(){ajax();},1000);


}


</script> -->
</body>
</html>