<?php


class MsgController {

    public function get_msg($msg,$destino,$con){
        try{
        $con->prepare("SELECT * FROM tbchat WHERE DESTINO = :destino");
        $con->bindValue(":destino",$destino);
        $con->execute();
        $result = $con->fetch(PDO::FETCH_ASSOC);
        
        return $result;
    
        }catch(Exception $e){
            return $e;
        }
    }
    
    public function get_all($con){
        try{
        $select = $con->prepare("SELECT * FROM tbchat");
        $select->execute();
        $result = $select->fetchAll(PDO::FETCH_ASSOC);        
    }catch(Exception $e){
        return $e;
    }
    return $result;
    }
    
    public function insert_msg($msg,$con){
        try{
        $insert = $con->prepare("INSERT INTO tbchat (msg,destio,origem)
                                 VALUES(:msg,:destino,:origem)");
        $insert->bindValue("msg",$msg->get_msg());
        $insert->bindValue("destino",$msg->get_destino());
        $insert->bindValue("origem",$msg->get_origem());
        $insert->execute();
        
        return $con;
    
        }catch(Exception $e){
            return $e;
        }
    }
}

?>