<?php
require_once "conection.php";
require_once "wo.php";
require_once "mensagem.php";
require_once "wo_controller.php";
require_once "msg_controller.php";


$conection = new Conection("conversa","localhost","root","");
$woController = new WoController();
$msgController = new MsgController();

echo "CON - ".var_dump($conection->get_pdo());
?>


<html>
<head>

<link rel="stylesheet" href="styles.css">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-Zenh87qX5JnK2Jl0vWa8Ck2rdkQ2Bzep5IDxbcnCeuOxjzrPF/et3URy9Bv1WTRi" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-OERcA2EqjJCMA+/3y+gxIOqMEjwtxJY7qPCqsdltbNJuaOe923+mo//f6V8Qbsw3" crossorigin="anonymous"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/3.9.1/chart.min.js" integrity="sha512-ElRFoEQdI5Ht6kZvyzXhYG9NqjtkmlkfYk0wr6wHxU9JEHakS7UJZNeml5ALk+8IKlU6jDgMabC3vkumRokgJA==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/3.9.1/chart.esm.js" integrity="sha512-59oaQE+Oz94NSelkRzYEkfwlKDjUj7IWGPlZQJwWtHjbkYxwjnVgwDV3mCn/Vg6CiLUVcdjZO+Kta2bjVemV3A==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/3.9.1/chart.esm.min.js" integrity="sha512-wp1TmWHEmHgERMuWw8Q0tCwFbZab0o6MjMS/HceqShRObCHzIfTrZfjpMm1bTuqIVrQXd9SRhYt0V9hObySU/g==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/3.9.1/chart.js" integrity="sha512-d6nObkPJgV791iTGuBoVC9Aa2iecqzJRE0Jiqvk85BhLHAPhWqkuBiQb1xz2jvuHNqHLYoN3ymPfpiB1o+Zgpw==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/3.9.1/helpers.esm.js" integrity="sha512-k1l60wcqxrkxs0F9M/sCgvBepWeLTIyc1Od+wN5tC0VhsLgksryon9jdB73d9CXi2E5bJA1wxl4CuPsRDWwadw==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/3.9.1/helpers.esm.min.js" integrity="sha512-SFaZeQpMkYy2mMnrH53KqmTt13JaAZfhFO3J/R5RhiOg6EXRbl4UJWSjPulMnhwaLELHrAl40WN9XwjPJHpjqQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>


</head>
<body>
    

<div class="container my-4">
    <div class="row">
        <div class="col-6">
            

        <?php
            if(isset($_POST['wo'])){
                $wo = addslashes($_POST['wo']);
                $ns = addslashes($_POST['ns']);
                $ncts = addslashes($_POST['ncts']);

                $woN = new Wo();
                $woN->set_wo($wo);
                $woN->set_ns($ns);
                $woN->set_ncts($ncts);

                $woController->insert_wo($woN,$conection->get_pdo());
            }
        
        ?>
            <form method="POST">
              <div class="mb-3">
                <label for="exampleInputEmail1" class="form-label">WO</label>
                <input type="text" class="form-control" id="wo" name="wo" aria-describedby="WO">
              </div>
              <div class="mb-3">
                <label for="ns1" class="form-label">NS</label>
                <input type="time" class="form-control" id="ns1" name="ns">
              </div>
              <div class="mb-3">
                <label for="ncts1" class="form-label">NCTS</label>
                <input type="date" class="form-control" id="ncts1" name="ncts">
              </div>
             
              <button type="submit" class="btn btn-primary">Submit</button>
            </form>

            <?php
            if(isset($_POST['nome'])){
                $origem = 'thithi';//addslashes($_POST['nome']);
                $msg = 'oi mundo';//addslashes($_POST['msg']);
                $destino = 'joao';

                $msgN = new Msg();

                $msgN->set_msg($msg);
                $msgN->set_origem($origem);
                $msgN->set_destino($destino);

                $msgController->insert_msg($msgN,$conection->get_pdo());
            }
        
        ?>

        <form action="POST">
            <input type="text" name="nome">
            <input type="text" name="msg">
            <input type="submit">
        </form>

        </div>
        <div class="col-4">
            

            <div class="container">
                
                <ul class="list-group mt-5 text-white" id="lista">   



           
                    
                </ul>
            </div>
        </div>
    </div>
</div>


<canvas id="myChart" width="400" height="400"></canvas>


<?php

  if(isset($_GET['del'])){
    $wo= addslashes($_GET['del']);

    $woN = new Wo();
    $woN->set_wo($wo);
    echo $woN->get_wo();

    $woController->delete_wo($woN,$conection->get_pdo());
    header("location: CRUD.php");
}


?>

<script>
const ctx = document.getElementById('myChart').getContext('2d');
const myChart = new Chart(ctx, {
    type: 'doughnut',
    data: {
        labels: ['Red', 'Blue', 'Yellow', 'Green', 'Purple', 'Orange'],
        datasets: [{
            label: '# of Votes',
            data: [12, 19, 3, 5, 2, 3],
            backgroundColor: [
                'rgba(255, 99, 132, 0.2)',
                'rgba(54, 162, 235, 0.2)',
                'rgba(255, 206, 86, 0.2)',
                'rgba(75, 192, 192, 0.2)',
                'rgba(153, 102, 255, 0.2)',
                'rgba(255, 159, 64, 0.2)'
            ],
            borderColor: [
                'rgba(255, 99, 132, 1)',
                'rgba(54, 162, 235, 1)',
                'rgba(255, 206, 86, 1)',
                'rgba(75, 192, 192, 1)',
                'rgba(153, 102, 255, 1)',
                'rgba(255, 159, 64, 1)'
            ],
            borderWidth: 1
        }]
    },
    options: {
        scales: {
            y: {
                beginAtZero: true
            }
        }
    }
});
</script>


<script>
  
// Access the array elements
var passedArray = <?php echo json_encode($woController->get_all($conection->get_pdo())); ?>;
       

function ordenar (wos){
    wos.sort(function (a, b) {
        if (a.NS > b.NS) {
        return -1;
        }
        else if (a.NS < b.NS) {
        return 1;
        }
        else {
            if (a.NCTS > b.NCTS) {
                return 1;
            }
            else if (a.NCTS < b.NCTS) {
                return -1;
            }
            else{
                return 0;
            }
        }
    });
    
}

function stringToDate(wos){

wosEd = []
try {
    wos.forEach(element => {
        
        words = element.NCTS.split('-')
        data = new Date(words[2]+"/"+words[1]+"/"+words[0])
        console.log(data.toLocaleDateString("pt-BR"))
    
        element.NCTS = data
        wosEd.push(element)
    });
} catch (error) {
    console.log(error)
}

return wosEd;
}


function print(wos){

wosE = stringToDate(wos);

ordenar(wosE);

wosE.forEach(element => {
    criarItem(element)
});

}

function criarItem(wo){

li = document.createElement("li");
li.classList.add("list-group-item");
li.classList.add("d-flex");
li.classList.add("justify-content-between");
li.classList.add("align-content-center");
li.innerHTML = '<div class="d-flex flex-row"> <img src="https://img.icons8.com/color/344/send-mass-email.png" width="40" /> <div class="ml-2"> <h6 class="mb-0">'+wo.WO+'</h6> <div class="about"> <span>Ns - '+wo.NS+'</span> <span>Ncts - '+wo.NCTS.toLocaleDateString("pt-BR")+'</span> </div> <span><a href="CRUD.php?del='+wo.ID+'" >DEL</a></span> </div> </div>'
document.getElementById("lista").appendChild(li)

}

print(passedArray);

console.log(passedArray)

</script>


<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js" integrity="sha384-oBqDVmMz9ATKxIep9tiCxS/Z9fNfEXiDAYTujMAeBAsjFuCZSmKbSSUnQlmh/jp3" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.min.js" integrity="sha384-IDwe1+LCz02ROU9k972gdyvl+AESN10+x7tBKgc9I5HFtuNz0wWnPclzo6p9vxnk" crossorigin="anonymous"></script>
</body>
</html>