<?php
require_once "conection.php";

class Msg
{
    private $msg;
    private $origem;
    private $destino;

    public function __contruct(){
    }

    public function get_msg(){
        return $this->msg;
    }
    public function get_origem(){
        return $this->origem;
    }
    public function get_destino(){
        return $this->destino;
    }
    
    public function set_msg($msg){
        $this->msg = $msg;
    }
    public function set_destino($destino){
        $this->destino = $destino;
    }
    public function set_origem($origem){
        $this->origem = $origem;
    }
}

?>